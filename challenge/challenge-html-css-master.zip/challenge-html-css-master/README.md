# Challenge-HTML-CSS

#CHALLENGE : 

Créer des animations en utilisant les spécificités CSS3  ( voir vidéo ) 

#Périmètre : 

La structure de la page HTML est déjà établie 
Les classes les id et les pseudo classes sont déjà établis dans le fichier style.css 
Utiliser CSS pour donner du style à votre challenge. 

#Indications : 

Le rendu contient la maquette (HTML et CSS). 
Utilisez la propriété : linear-gradient() pour jouer sur les couleurs du fond de l’image .
Pour orner l’image et la couper du bas utilisez le lien suivant :   https://bennettfeely.com/clippy/

Pour les animations utilisez la clause : @keyframes nom de l’animation , ainsi que les propriété suivantes : 
Animation-name , animation-duration ,animation-timing-function 

Au sein des @keyframes utilisez la clause : transform et ses valeurs. 

Les pseudo classes comme : after, hover vous permet de jouer sur l’animation du bouton  

#Améliorations possibles

Vous pouvez ajouter les animations de votre choix, les Framework ne sont pas permis dans ce challenge.

Animation-fill-mode : une clause qui vous permet d’afficher le bouton que jusqu’à son temps d’animation 

PS : Je vous souhaite bon courage  , la video vous sera diffusée au moment du début du challenge . 

# @TIJANIABDELLATIF  , Formateur réfèrent @Youcode 
